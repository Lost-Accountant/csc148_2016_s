
class Customer:
    """A Customer.

    This class represents a customer in the simulation. Each customer will
    enter the simulation at _entry_time, will wait at most _patience turns.
    The restaurant need _prepare_time turns to prepare this customer order,
    and will receive _profit if can serve this customer on time.
    
    Your main task is to implement the remaining methods.
    """

    # === Private Attributes ===
    # TODO: Complete this part

    def __init__(self, definition):
        """# TODO: Complete this part
        """
        
        # TODO: Complete this part


    def id(self):
        """# TODO: Complete this part
        """
        
        # TODO: Complete this part

    # TODO: Complete this part

